#!/usr/bin/python

import BaseHTTPServer, SimpleHTTPServer
import ssl
import sys

if len (sys.argv) != 2 :
    print "Enter the ssl port number as cmd line argument"
    sys.exit (1)

httpd = BaseHTTPServer.HTTPServer(('0.0.0.0', int(sys.argv[1])), SimpleHTTPServer.SimpleHTTPRequestHandler)
httpd.socket = ssl.wrap_socket (httpd.socket, server_side=True,
                                certfile='yourpemfile.pem')
print "Serving HTTPS on 0.0.0.0 port ",sys.argv[1]," ..."
httpd.serve_forever()
