#!/bin/bash

openssl req -new -x509 -keyout yourpemfile.pem -out yourpemfile.pem -days 365 -nodes
